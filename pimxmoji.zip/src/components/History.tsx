import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Trash2, Download, Clock, Shield, Info, RefreshCw, Wand2 } from 'lucide-react';
import { ArtOptions } from '../utils/imageProcessing';

export interface HistoryItem {
  id: string;
  timestamp: number;
  imageData: string;
  options: ArtOptions;
  name?: string;
}

interface HistoryProps {
  items: HistoryItem[];
  onDelete: (id: string) => void;
  onDownload: (item: HistoryItem) => void;
  onApply: (item: HistoryItem) => void;
}

export function History({ items, onDelete, onDownload, onApply }: HistoryProps) {
  if (items.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center space-y-4">
        <div className="w-16 h-16 bg-zinc-100 dark:bg-zinc-900 rounded-full flex items-center justify-center text-zinc-400">
          <Clock className="w-8 h-8" />
        </div>
        <div className="space-y-1">
          <h3 className="text-lg font-bold text-zinc-900 dark:text-white">No history yet</h3>
          <p className="text-sm text-zinc-500 max-w-xs">Your created masterpieces will appear here once you start generating.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3 p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl text-emerald-600 dark:text-emerald-400">
        <Shield className="w-5 h-5 flex-shrink-0" />
        <p className="text-xs font-bold leading-tight">
          Your data is stored locally in your browser. For maximum security, nothing is uploaded to our servers.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        <AnimatePresence mode="popLayout">
          {items.map((item) => (
            <motion.div
              key={item.id}
              layout
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="group relative bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-all"
            >
              <div className="aspect-square bg-zinc-100 dark:bg-zinc-950 relative overflow-hidden">
                <img src={item.imageData} alt="History Art" className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-zinc-950/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3">
                  <button
                    onClick={() => onApply(item)}
                    className="p-3 bg-white text-zinc-950 rounded-full hover:bg-violet-500 hover:text-white transition-colors shadow-lg group/btn relative"
                    title="Use this style"
                  >
                    <Wand2 className="w-5 h-5" />
                    <span className="absolute -top-8 left-1/2 -translate-x-1/2 bg-zinc-900 text-white text-[10px] px-2 py-1 rounded opacity-0 group-hover/btn:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
                      Use Style
                    </span>
                  </button>
                  <button
                    onClick={() => onDownload(item)}
                    className="p-3 bg-white text-zinc-950 rounded-full hover:bg-emerald-500 hover:text-white transition-colors shadow-lg group/btn relative"
                    title="Download image"
                  >
                    <Download className="w-5 h-5" />
                    <span className="absolute -top-8 left-1/2 -translate-x-1/2 bg-zinc-900 text-white text-[10px] px-2 py-1 rounded opacity-0 group-hover/btn:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
                      Download
                    </span>
                  </button>
                  <button
                    onClick={() => onDelete(item.id)}
                    className="p-3 bg-white text-zinc-950 rounded-full hover:bg-red-500 hover:text-white transition-colors shadow-lg group/btn relative"
                    title="Delete from history"
                  >
                    <Trash2 className="w-5 h-5" />
                    <span className="absolute -top-8 left-1/2 -translate-x-1/2 bg-zinc-900 text-white text-[10px] px-2 py-1 rounded opacity-0 group-hover/btn:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
                      Delete
                    </span>
                  </button>
                </div>
              </div>
              <div className="p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-black uppercase tracking-widest text-zinc-400">
                    {new Date(item.timestamp).toLocaleDateString()}
                  </span>
                  <div className="flex items-center gap-1">
                    <div className="w-2 h-2 rounded-full bg-violet-500" />
                    <span className="text-[10px] font-bold text-zinc-500 uppercase">{item.options.mode}</span>
                  </div>
                </div>
                <div className="flex flex-wrap gap-1">
                  {Array.from(item.options.chars).slice(0, 5).map((c, i) => (
                    <span key={i} className="px-1.5 py-0.5 bg-zinc-100 dark:bg-zinc-800 rounded text-[10px] font-mono text-zinc-600 dark:text-zinc-400">
                      {c === ' ' ? '␣' : c}
                    </span>
                  ))}
                  {Array.from(item.options.chars).length > 5 && <span className="text-[10px] text-zinc-400">...</span>}
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}
